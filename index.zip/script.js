
// Load saved data from browser
let donors = JSON.parse(localStorage.getItem("donors")) || [];
let foods = JSON.parse(localStorage.getItem("foods")) || [];
let distributions = JSON.parse(localStorage.getItem("distributions")) || [];

// Save data
function saveData() {
    localStorage.setItem("donors", JSON.stringify(donors));
    localStorage.setItem("foods", JSON.stringify(foods));
    localStorage.setItem("distributions", JSON.stringify(distributions));
}

// Change website page
function showPage(page) {
    document.querySelectorAll(".page").forEach(section => {
        section.classList.remove("active");
    });

    document.getElementById(page).classList.add("active");

    const titles = {
        dashboard: "Dashboard",
        donors: "Donor Management",
        inventory: "Food Inventory Management",
        distribution: "Food Distribution",
        reports: "Admin and Reports"
    };

    document.getElementById("pageTitle").textContent = titles[page];
    updateDashboard();
}

// Donor registration
document.getElementById("donorForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const donor = {
        name: document.getElementById("donorName").value.trim(),
        phone: document.getElementById("donorPhone").value.trim(),
        address: document.getElementById("donorAddress").value.trim()
    };

    donors.push(donor);
    saveData();

    this.reset();
    displayDonors();
    updateDashboard();

    alert("Donor registered successfully!");
});

// Display donors
function displayDonors() {
    const table = document.getElementById("donorTable");
    table.innerHTML = "";

    donors.forEach(donor => {
        const row = document.createElement("tr");

        [donor.name, donor.phone, donor.address].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        table.appendChild(row);
    });
}

// Add food to inventory
document.getElementById("foodForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("foodName").value.trim();
    const quantity = Number(document.getElementById("foodQuantity").value);
    const expiry = document.getElementById("foodExpiry").value;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const expiryDate = new Date(expiry + "T00:00:00");

    if (!name || !Number.isInteger(quantity) || quantity <= 0) {
        alert("Enter a valid food name and quantity.");
        return;
    }

    if (!expiry || expiryDate < today) {
        alert("Please select today or a future expiry date.");
        return;
    }

    foods.push({
        name: name,
        quantity: quantity,
        expiry: expiry
    });

    saveData();
    this.reset();

    displayFoods();
    updateDashboard();

    alert("Food added successfully!");
});

// Display food inventory
function displayFoods() {
    const table = document.getElementById("foodTable");
    const select = document.getElementById("distributionFood");

    table.innerHTML = "";
    select.innerHTML = '<option value="">Select Food Item</option>';

    foods.forEach((food, index) => {
        const row = document.createElement("tr");

        [food.name, food.quantity, food.expiry].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        table.appendChild(row);

        if (food.quantity > 0) {
            const option = document.createElement("option");
            option.value = index;
            option.textContent = food.name + " (" + food.quantity + " available)";
            select.appendChild(option);
        }
    });
}

// Distribute food
document.getElementById("distributionForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const index = Number(document.getElementById("distributionFood").value);
    const quantity = Number(document.getElementById("distributionQuantity").value);
    const receiver = document.getElementById("receiverName").value.trim();

    if (document.getElementById("distributionFood").value === "") {
        alert("Please select a food item.");
        return;
    }

    const food = foods[index];

    if (!food || !Number.isInteger(quantity) || quantity <= 0 || quantity > food.quantity) {
        alert("Please enter a valid quantity within available stock.");
        return;
    }

    food.quantity -= quantity;

    distributions.push({
        food: food.name,
        quantity: quantity,
        receiver: receiver,
        date: new Date().toLocaleDateString()
    });

    saveData();
    this.reset();

    displayFoods();
    displayDistributions();
    updateDashboard();

    alert("Food distributed successfully!");
});

// Display distribution records
function displayDistributions() {
    const table = document.getElementById("distributionTable");
    table.innerHTML = "";

    distributions.forEach(record => {
        const row = document.createElement("tr");

        [record.food, record.quantity, record.receiver, record.date].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        table.appendChild(row);
    });
}

// Update dashboard statistics
function updateDashboard() {
    const totalFood = foods.length;
    const available = foods.reduce((sum, food) => sum + food.quantity, 0);
    const distributed = distributions.reduce((sum, item) => sum + item.quantity, 0);

    document.getElementById("donorCount").textContent = donors.length;
    document.getElementById("foodCount").textContent = totalFood;
    document.getElementById("availableCount").textContent = available;
    document.getElementById("distributedCount").textContent = distributed;

    document.getElementById("reportDonations").textContent =
        foods.reduce((sum, food) => sum + food.quantity, 0) + distributed;

    document.getElementById("reportDistributed").textContent = distributed;
}

// Download report as CSV
function downloadReport() {
    const rows = [
        ["Food Name", "Quantity", "Receiver", "Date"]
    ];

    distributions.forEach(record => {
        rows.push([
            record.food,
            record.quantity,
            record.receiver,
            record.date
        ]);
    });

    const csv = rows.map(row =>
        row.map(value => '"' + String(value).replace(/"/g, '""') + '"').join(",")
    ).join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "FoodCare_Report.csv";
    link.click();

    URL.revokeObjectURL(url);
}

// Load saved information when website opens
displayDonors();
displayFoods();
displayDistributions();
updateDashboard();
