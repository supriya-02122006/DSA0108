#include <iostream>
#include <string>
class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& n, int a) : name(n), age(a) {}
};
class Address {
    std::string city;
    int pin;
public:
    Address(const std::string& c, int p) : city(c), pin(p) {}
    std::string str() const { return city + "-" + std::to_string(pin); }
};
class Student : public Person {
    long long regNo;
    Address home;
public:
    Student(const std::string& n, int a, long long r, const std::string& c, int p)
        : Person(n, a), regNo(r), home(c, p) {}
    void print() const { std::cout << regNo << ' ' << name << " (" << age << ") " << home.str() << '\n'; }
};
int main() {
    std::string n, c; int a, p; long long r;
    std::cin >> n >> a >> r >> c >> p;
    Student s(n, a, r, c, p);
    s.print();
}
