#include <iomanip>
#include <iostream>
#include <string>
class Cart {
    std::string items[10];
    double prices[10];
    int n = 0;
    double discount = 0;
public:
    Cart& add(const std::string& item, double price) {
        if (n < 10) { items[n] = item; prices[n] = price; ++n; }
        return *this;
    }
    Cart& setDiscount(double discount) {
        this->discount = discount;
        return *this;
    }
    double total() const {
        double t = 0;
        for (int i = 0; i < n; ++i) t += prices[i];
        return t * (100 - discount) / 100;
    }
};
int main() {
    double p1, p2, p3, disc;
    std::cin >> p1 >> p2 >> p3 >> disc;
    Cart c;
    c.add("Rice", p1).add("Dal", p2).setDiscount(disc);
    Cart* p = &c;
    p->add("Oil", p3);
    std::cout << std::fixed << std::setprecision(2) << p->total() << '\n';
}
